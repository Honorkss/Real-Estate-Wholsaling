# Wholesale Real Estate Platform

## Setup Instructions
1. Copy `.env.example` to `.env` and fill in your keys.
2. Run the included script to install dependencies, build frontend, and start the backend.
   - Windows: `run_site.bat`
   - Linux/Mac: `run_site.sh`