from flask import Flask, jsonify, request, session, send_from_directory
from flask_cors import CORS
from models import db, Property
import os
import smtplib
from email.message import EmailMessage
import pathlib

app = Flask(__name__, static_folder='build')
CORS(app)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///properties.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.secret_key = os.getenv("SECRET_KEY", "dev_secret")
db.init_app(app)

with app.app_context():
    db.create_all()

def send_email_notification(property):
    try:
        msg = EmailMessage()
        msg.set_content(f"New Property Listed:\n\nTitle: {property.title}\nPrice: ${property.price}\nLocation: {property.location}\nDescription: {property.description}")
        msg['Subject'] = 'New Wholesale Property Alert'
        msg['From'] = os.getenv("EMAIL_USER")
        msg['To'] = os.getenv("EMAIL_RECIPIENT")
        with smtplib.SMTP_SSL('smtp.gmail.com', 465) as smtp:
            smtp.login(os.getenv("EMAIL_USER"), os.getenv("EMAIL_PASSWORD"))
            smtp.send_message(msg)
    except Exception as e:
        print(f"Email failed: {e}")

@app.route('/api/properties', methods=['GET'])
def get_properties():
    properties = Property.query.all()
    return jsonify([{
        'id': p.id,
        'title': p.title,
        'price': p.price,
        'location': p.location,
        'lat': p.lat,
        'lng': p.lng,
        'description': p.description
    } for p in properties])

@app.route('/api/properties', methods=['POST'])
def add_property():
    if not session.get('admin'):
        return jsonify({'message': 'Unauthorized'}), 401
    data = request.json
    prop = Property(
        title=data['title'],
        price=data['price'],
        location=data['location'],
        lat=data.get('lat'),
        lng=data.get('lng'),
        description=data['description']
    )
    db.session.add(prop)
    db.session.commit()
    send_email_notification(prop)
    return jsonify({'message': 'Property added successfully'}), 201

@app.route('/api/login', methods=['POST'])
def login():
    data = request.json
    if data['username'] == os.getenv("ADMIN_USER") and data['password'] == os.getenv("ADMIN_PASSWORD"):
        session['admin'] = True
        return jsonify({'message': 'Logged in'})
    return jsonify({'message': 'Invalid credentials'}), 401

@app.route('/api/logout', methods=['POST'])
def logout():
    session.pop('admin', None)
    return jsonify({'message': 'Logged out'})

# Serve React frontend
frontend_build_dir = os.path.join(os.path.dirname(__file__), 'build')

@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve_frontend(path):
    if path != "" and pathlib.Path(os.path.join(frontend_build_dir, path)).exists():
        return send_from_directory(frontend_build_dir, path)
    else:
        return send_from_directory(frontend_build_dir, 'index.html')

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=int(os.getenv("PORT", 5000)))