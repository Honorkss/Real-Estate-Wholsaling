#!/bin/bash
pip install -r requirements.txt
cd ../frontend
npm install
npm run build
mv build ../backend/
cd ../backend
python app.py