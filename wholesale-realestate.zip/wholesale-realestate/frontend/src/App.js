import React, { useState, useEffect } from 'react';
import PropertyList from './components/PropertyList';
import SearchFilter from './components/SearchFilter';
import MapComponent from './components/MapComponent';

function App() {
  const [properties, setProperties] = useState([]);
  const [query, setQuery] = useState('');

  const fetchProperties = () => {
    fetch('/api/properties')
      .then(res => res.json())
      .then(data => setProperties(data));
  };

  useEffect(() => { fetchProperties(); }, []);

  const filtered = properties.filter(p =>
    p.title.toLowerCase().includes(query.toLowerCase()) ||
    p.location.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-3xl font-bold mb-4">Wholesale Real Estate Listings</h1>
      <SearchFilter query={query} setQuery={setQuery} />
      <MapComponent properties={filtered} />
      <PropertyList properties={filtered} />
    </div>
  );
}

export default App;