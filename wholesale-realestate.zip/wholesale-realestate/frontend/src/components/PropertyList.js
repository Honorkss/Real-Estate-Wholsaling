import React from 'react';

const PropertyList = ({ properties }) => (
  <div className="grid md:grid-cols-2 gap-4 mt-4">
    {properties.map(prop => (
      <div key={prop.id} className="border rounded p-4 shadow hover:shadow-lg transition">
        <h3 className="font-bold text-lg">{prop.title}</h3>
        <p className="text-green-600 font-semibold">${prop.price}</p>
        <p className="text-gray-500">{prop.location}</p>
        <p>{prop.description}</p>
      </div>
    ))}
  </div>
);

export default PropertyList;