import React from 'react';
import { GoogleMap, LoadScript, Marker } from '@react-google-maps/api';

const MapComponent = ({ properties }) => {
  const containerStyle = { width: '100%', height: '400px' };
  const center = { lat: 39.5, lng: -98.35 };

  return (
    <LoadScript googleMapsApiKey={process.env.REACT_APP_GOOGLE_MAPS_API_KEY || ''}>
      <GoogleMap mapContainerStyle={containerStyle} center={center} zoom={4}>
        {properties.map(p => p.lat && p.lng && (
          <Marker key={p.id} position={{ lat: p.lat, lng: p.lng }} title={p.title} />
        ))}
      </GoogleMap>
    </LoadScript>
  );
};

export default MapComponent;