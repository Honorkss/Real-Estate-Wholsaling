import React from 'react';

const SearchFilter = ({ query, setQuery }) => (
  <input
    type="text"
    placeholder="Search by title or location"
    value={query}
    onChange={e => setQuery(e.target.value)}
    className="border rounded p-2 w-full md:w-1/2 mb-4"
  />
);

export default SearchFilter;